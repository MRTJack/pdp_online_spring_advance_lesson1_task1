//package uz.pdp.app_pdp_online_2_lesson1.task2.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import uz.pdp.app_pdp_online_2_lesson1.task1.payload.ApiResult;
//import uz.pdp.app_pdp_online_2_lesson1.task2.dto.SubmissionDTO;
//import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.Submission;
//import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.User;
//
//import java.util.List;
//
//public interface SubmissionService {
//    List<Submission> getAllSubmissionForUser();
//
//    List<Submission> getSubmissionByUserId(Long submissionId);
//
//    ApiResult submitSolution(SubmissionDTO submissionDTO, Long userId);
//
//
//    Submission getSubmissionDetails(Long submissionId);
//}
