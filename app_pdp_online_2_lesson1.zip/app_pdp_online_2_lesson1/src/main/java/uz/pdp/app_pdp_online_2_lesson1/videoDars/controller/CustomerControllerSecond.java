package uz.pdp.app_pdp_online_2_lesson1.videoDars.controller;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import uz.pdp.app_pdp_online_2_lesson1.videoDars.dto.CustomerDTO;
import uz.pdp.app_pdp_online_2_lesson1.videoDars.entity.Customer;
import uz.pdp.app_pdp_online_2_lesson1.videoDars.payload.ApiResult;
import uz.pdp.app_pdp_online_2_lesson1.videoDars.service.CustomerService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
//@RequestMapping("/api/customers")
public class CustomerControllerSecond {
    @Autowired
    CustomerService customerService;


    /**
     * Bu yerda barcha mijozlar ruyxatini qaytaramiz
     *
     * @return CUSTOMERS
     */
    @GetMapping("/api/customer")
    public ResponseEntity<List<Customer>> getCustomers() {
        List<Customer> customers = customerService.getCustomers();
        return ResponseEntity.ok(customers);
    }

    /**
     * ID orqali bitta mijozni qaytaramiz
     *
     * @param id INTEGER
     * @return CUSTOMER
     * Agar ID orqali mijoz topilmasa null qiymat qaytsin
     */
    @GetMapping("/api/customer/{id}")
    public HttpEntity<Customer> getCustomer(@PathVariable Integer id) {
        Customer customerById = customerService.getCustomerById(id);
        return ResponseEntity.ok(customerById);
    }


    /**
     * Mijoz qushadigan metod
     *
     * @return ApiResult
     * Bizga CustomerDTO tipida JSON object keladi
     * Validatsiya quydik
     */
    @PostMapping("/api/customer/add")
    public HttpEntity<ApiResult> addCustomer(@Valid @RequestBody CustomerDTO customerDTO) {
        ApiResult apiResult = customerService.addCustomer(customerDTO);
//        if (apiResult.isSuccess()) {
//            return ResponseEntity.status(201).body(apiResult);
//        }
//        return ResponseEntity.status(HttpStatus.CONFLICT).body(apiResult);
//    }
        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.CREATED
                : HttpStatus.CONFLICT).body(apiResult);
    }

    /**
     * Mijozni tahrirlash
     *
     * @param id
     * @param customerDTO
     * @return ApiResult
     * Bizga yulda Id va RequestBodysida CustomerDTO tipida JSON object beradi
     */

    @PutMapping("/api/customer/edit/{id}")
    public HttpEntity<ApiResult> editCustomer(@Valid @PathVariable Integer id, @RequestBody CustomerDTO customerDTO) {
        ApiResult apiResult = customerService.editCustomer(id, customerDTO);
        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.ACCEPTED
                : HttpStatus.CONFLICT).body(apiResult);
    }

    /**
     * Mijozni uchirish id orqali yulda id ni beradi
     *
     * @param id
     * @return ApiResult
     */
    @DeleteMapping("/api/customer/delete/{id}")
    public ResponseEntity<?> deleteCustomer(@PathVariable Integer id) {
        ApiResult apiResult = customerService.deleteCustomer(id);
        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.ACCEPTED
                : HttpStatus.CONFLICT).body(apiResult);

    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }

}
