package uz.pdp.app_pdp_online_2_lesson1.task1.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Company;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Department;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Worker;

import java.util.Optional;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
    boolean existsDepartmentByCompany_DirectorName(String company_DirectorNames);

    boolean existsDepartmentByCompany_DirectorNameAndIdNot(String company_DirectorNames, Integer id);

    Optional<Department> findById(Integer id);
}

