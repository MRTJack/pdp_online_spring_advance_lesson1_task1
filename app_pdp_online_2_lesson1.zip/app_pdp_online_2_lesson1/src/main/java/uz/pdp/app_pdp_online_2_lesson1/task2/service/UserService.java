//package uz.pdp.app_pdp_online_2_lesson1.task2.service;
//
//import uz.pdp.app_pdp_online_2_lesson1.task1.payload.ApiResult;
//import uz.pdp.app_pdp_online_2_lesson1.task2.dto.UserDTO;
//import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.User;
//
//public interface UserService {
//    ApiResult registerUser(UserDTO userDTO);
//
//    ApiResult loginUser(UserDTO userDTO);
//
//    User getCurrentUser(String sessionId);
//}
