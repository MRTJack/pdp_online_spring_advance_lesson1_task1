package uz.pdp.app_pdp_online_2_lesson1.task2.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.Problem;

import java.util.List;

public interface ProblemRepository extends JpaRepository<Problem, Long> {
    List<Problem> findBySubcategoryId(Long subcategoryId);
}
