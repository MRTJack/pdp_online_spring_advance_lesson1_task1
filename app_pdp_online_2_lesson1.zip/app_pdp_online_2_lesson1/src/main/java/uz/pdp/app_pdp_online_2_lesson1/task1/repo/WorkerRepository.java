package uz.pdp.app_pdp_online_2_lesson1.task1.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Worker;

import java.util.Optional;

public interface WorkerRepository extends JpaRepository<Worker, Long> {
    boolean existsWorkerByPhoneNumber(String phoneNumber);

    Optional<Worker> findById(Integer id);
}
