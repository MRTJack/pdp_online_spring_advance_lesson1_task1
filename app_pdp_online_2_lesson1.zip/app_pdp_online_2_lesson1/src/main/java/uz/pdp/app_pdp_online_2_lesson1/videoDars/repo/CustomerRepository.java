package uz.pdp.app_pdp_online_2_lesson1.videoDars.repo;

import jakarta.validation.constraints.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import uz.pdp.app_pdp_online_2_lesson1.videoDars.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {
    boolean existsByPhoneNumber(@NotNull String phoneNumber);
    boolean existsByPhoneNumberAndIdNot(String phone_number, Integer id);
}
