package uz.pdp.app_pdp_online_2_lesson1.task1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.pdp.app_pdp_online_2_lesson1.task1.dto.CompanyDTO;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Company;
import uz.pdp.app_pdp_online_2_lesson1.task1.payload.ApiResult;
import uz.pdp.app_pdp_online_2_lesson1.task1.repo.CompanyRepository;

import java.util.List;
import java.util.Optional;

@Service
public class CompanyService {
    @Autowired
    CompanyRepository companyRepository;

    /**
     * Hamma company larni ruyhatini qaytaradi
     *
     * @return Company
     */
    public List<Company> getAllCompanies() {
        return companyRepository.findAll();
    }

    /**
     * Company ni id orqali qaytardi
     *
     * @param id
     * @return Company
     */
    public Company getCompanyById(Integer id) {
        return companyRepository.findById(id).orElse(null);
    }


    //1-variant add qilish metodi
//    public ApiResult addCompany(CompanyDTO companyDTO) {
//        boolean existsCompaniesByCorpName = companyRepository.existsCompaniesByCorpName(companyDTO.getCorpName());
//        if (existsCompaniesByCorpName) {
//            return new ApiResult("Bunday company mavjud", false);
//        }
//        Company company = new Company();
//        company.setCorpName(companyDTO.getCorpName());
//        company.setDirectorName(companyDTO.getDirectorName());
//        company.setAddress(companyDTO.getAddress());
//        companyRepository.save(company);
//        return new ApiResult("Company saqlandi", true);
//    }

    //2- variant add qilish metodi
    public ApiResult addCompany(CompanyDTO companyDTO) {
        String corpName = companyDTO.getCorpName();

        if (companyRepository.existsCompaniesByCorpName(corpName)) {
            return new ApiResult("Bu nomdagi kompaniya mavjud", false);
        }

        Company newCompany = createCompanyFromDTO(companyDTO);
        companyRepository.save(newCompany);

        return new ApiResult("Kompaniya qushildi", true);
    }

    private Company createCompanyFromDTO(CompanyDTO companyDTO) {
        Company company = new Company();
        company.setCorpName(companyDTO.getCorpName());
        company.setDirectorName(companyDTO.getDirectorName());
        company.setAddress(companyDTO.getAddress());
        return company;
    }

    public ApiResult editCompany(Integer id, CompanyDTO companyDTO) {
        return companyRepository.existsCompaniesByCorpNameAndIdNot(companyDTO.getCorpName(), id)
                ? new ApiResult("Bunday nomli company mavjud", false)
                : companyRepository.findById(id)
                .map(company -> updateCompanyFromDTO(company, companyDTO))
                .map(companyRepository::save)
                .map(saveCompany -> new ApiResult("Comapny tahririlandi", true))
                .orElse(new ApiResult("Bunday nomli company mavjud emas", false));
    }

    private Company updateCompanyFromDTO(Company company, CompanyDTO companyDTO) {
        company.setAddress(companyDTO.getAddress());
        company.setCorpName(companyDTO.getCorpName());
        company.setDirectorName(companyDTO.getDirectorName());
        return company;
    }

    public ApiResult deleteCompany(Integer id) {
        try {
            companyRepository.deleteById(id);
            return new ApiResult("Company uchirildi", true);
        } catch (Exception e) {
            return new ApiResult("Xatolik", false);
        }
    }

}
