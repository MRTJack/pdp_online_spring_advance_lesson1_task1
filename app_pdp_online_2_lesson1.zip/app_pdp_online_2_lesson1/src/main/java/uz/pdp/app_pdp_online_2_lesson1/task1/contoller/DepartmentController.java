package uz.pdp.app_pdp_online_2_lesson1.task1.contoller;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import uz.pdp.app_pdp_online_2_lesson1.task1.dto.DepartmentDTO;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Department;
import uz.pdp.app_pdp_online_2_lesson1.task1.payload.ApiResult;
import uz.pdp.app_pdp_online_2_lesson1.task1.repo.DepartmentRepository;
import uz.pdp.app_pdp_online_2_lesson1.task1.service.DepartmentService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/department")
public class DepartmentController {
    @Autowired
    DepartmentService departmentService;

    @GetMapping("")
    public ResponseEntity<List<Department>> getDepartment() {
        List<Department> allDepartment = departmentService.getAllDepartment();
        return ResponseEntity.ok(allDepartment);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Department> getDepartmentById(@PathVariable Long id) {
        Department departmentById = departmentService.getDepartmentById(id);
        return ResponseEntity.ok(departmentById);
    }

    @PostMapping("/add")
    public HttpEntity<ApiResult> addDepartment(@Valid @RequestBody DepartmentDTO departmentDTO) {
        ApiResult apiResult = departmentService.addDepartment(departmentDTO);
        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.CREATED : HttpStatus.CONFLICT)
                .body(apiResult);
    }

    @PutMapping("/edit/{id}")
    public ResponseEntity<ApiResult> editDepartment(@Valid @PathVariable Integer id, @RequestBody DepartmentDTO departmentDTO) {
        ApiResult apiResult = departmentService.editDepartment(departmentDTO, id);
        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.ACCEPTED : HttpStatus.CONFLICT)
                .body(apiResult);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<ApiResult> deleteDepartment(@PathVariable Long id) {
        ApiResult apiResult = departmentService.deleteDepartment(id);
        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.ACCEPTED : HttpStatus.CONFLICT)
                .body(apiResult);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }

}
