package uz.pdp.app_pdp_online_2_lesson1.videoDars.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDTO {

    @NotNull(message = "full_name bush bulmasligi kerak")
    private String full_name;

    @NotNull(message = "Phone number raqam bosh bulmasligi kerak")
    private String phoneNumber;

    @NotNull(message = "Address bush bulmasligi kerak")
    private String address;
}
