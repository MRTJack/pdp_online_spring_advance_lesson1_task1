package uz.pdp.app_pdp_online_2_lesson1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppPdpOnline2Lesson1Application {

    public static void main(String[] args) {
        SpringApplication.run(AppPdpOnline2Lesson1Application.class, args);
    }

}
