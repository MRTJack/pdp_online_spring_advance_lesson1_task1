//package uz.pdp.app_pdp_online_2_lesson1.task2.eninty;
//
//import jakarta.persistence.*;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import org.springframework.beans.factory.annotation.Autowired;
//
//@AllArgsConstructor
//@NoArgsConstructor
//@Data
//@Entity
//public class Submission {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    @ManyToOne
//    @JoinColumn(name = "user_id")
//    private User user;
//
//    @ManyToOne
//    @JoinColumn(name = "problem_id")
//    private Problem problem;
//
//    private String solution;
//
//}
