//package uz.pdp.app_pdp_online_2_lesson1.task2.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//import uz.pdp.app_pdp_online_2_lesson1.task2.dto.SubmissionDTO;
//import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.Submission;
//import uz.pdp.app_pdp_online_2_lesson1.task2.service.SubmissionService;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/api/submissions")
//public class SubmitController {
//    @Autowired
//    private SubmissionService submissionService;
//
//    /**
//     * Shu userga tegishli hamma javoblarni olish uchun controller
//     * @param user_id
//     * @return Submission
//     */
//    @GetMapping("/user/{user_id}")
//    public ResponseEntity<List<Submission>> getUserSubmission(@PathVariable Long user_id) {
//        List<Submission> submissionByUserId = submissionService.getSubmissionByUserId(user_id);
//        return ResponseEntity.ok(submissionByUserId);
//    }
//
//    /**
//     * Topshiriqni yechimini tafsilotlarini olishni kuradigan controller
//     * @param submission_id
//     * @return
//     */
//    @GetMapping("/{submission_id}")
//    public ResponseEntity<Submission> getSubmissionDetail(@PathVariable Long submission_id) {
//        Submission submissionDetails = submissionService.getSubmissionDetails(submission_id);
//        return ResponseEntity.ok(submissionDetails);
//    }
//
//}
