package uz.pdp.app_pdp_online_2_lesson1.task1.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DepartmentDTO {
    @NotNull(message = "Department name bush bulishi mumkin emas")
    private String name;
    private Long companyId;

}
