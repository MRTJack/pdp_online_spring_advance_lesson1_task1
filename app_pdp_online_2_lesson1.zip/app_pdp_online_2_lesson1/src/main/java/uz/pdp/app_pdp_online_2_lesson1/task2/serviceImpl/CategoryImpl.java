package uz.pdp.app_pdp_online_2_lesson1.task2.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.Category;
import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.Problem;
import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.Subcategory;
import uz.pdp.app_pdp_online_2_lesson1.task2.repo.CategoryRepository;
import uz.pdp.app_pdp_online_2_lesson1.task2.repo.ProblemRepository;
import uz.pdp.app_pdp_online_2_lesson1.task2.repo.SubcategoryRepository;
import uz.pdp.app_pdp_online_2_lesson1.task2.service.CategoryService;

import java.util.List;

@Service
public class CategoryImpl implements CategoryService {
    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private SubcategoryRepository subcategoryRepository;

    @Autowired
    private ProblemRepository problemRepository;

    @Override
    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    @Override
    public List<Subcategory> getSubcategoriesByCategoryId(Long categoryId) {
        return subcategoryRepository.findByCategoryId(categoryId);
    }

    @Override
    public List<Problem> getProblemsBySubcategoryId(Long subcategoryId) {
        return problemRepository.findBySubcategoryId(subcategoryId);
    }
}
