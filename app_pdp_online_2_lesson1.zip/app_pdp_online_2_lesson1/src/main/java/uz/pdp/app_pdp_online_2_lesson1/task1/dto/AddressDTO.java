package uz.pdp.app_pdp_online_2_lesson1.task1.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Address;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddressDTO extends Address {
    @NotNull(message = "Street bush bulishi mumkin emas")
    private String street;

    @NotNull(message = "Home number bush bulishi mumkin emas")
    private String homeNumber;

}

