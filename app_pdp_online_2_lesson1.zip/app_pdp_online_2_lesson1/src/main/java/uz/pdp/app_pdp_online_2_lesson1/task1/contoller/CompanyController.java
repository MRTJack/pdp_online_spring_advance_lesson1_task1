package uz.pdp.app_pdp_online_2_lesson1.task1.contoller;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import uz.pdp.app_pdp_online_2_lesson1.task1.dto.CompanyDTO;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Company;
import uz.pdp.app_pdp_online_2_lesson1.task1.payload.ApiResult;
import uz.pdp.app_pdp_online_2_lesson1.task1.service.CompanyService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/company")
public class CompanyController {
    @Autowired
    CompanyService companyService;


    /**
     * Compny larni ruyhaini qaytaradi
     * @return
     */
    @GetMapping("")
    public ResponseEntity<List<Company>> getAllCompany() {
        List<Company> allCompanies = companyService.getAllCompanies();
        return ResponseEntity.ok(allCompanies);
    }

    /**
     * Company ni id orqali qaytaradi
     * @param id
     * @return Company
     */
    @GetMapping("/{id}")
    public ResponseEntity<Company> getCompanyById(@PathVariable Integer id) {
        Company companyById = companyService.getCompanyById(id);
        return ResponseEntity.ok(companyById);
    }

    /**
     * Company qushuvchi  metod
     * @param companyDTO
     * @return ApiResult
     */
    @PostMapping("/add")
    public ResponseEntity<ApiResult> addCompany(@Valid @RequestBody CompanyDTO companyDTO) {
        ApiResult apiResult = companyService.addCompany(companyDTO);
        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.CREATED : HttpStatus.CONFLICT)
                .body(apiResult);
    }

    /**
     * Company ni edit qiluvchi metod
     * @param id
     * @param companyDTO
     * @return ApiResult
     */

    @PutMapping("/edit/{id}")
    public HttpEntity<ApiResult> editCompany(@Valid @PathVariable Integer id, @RequestBody CompanyDTO companyDTO) {
        ApiResult apiResult = companyService.editCompany(id, companyDTO);
        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.ACCEPTED : HttpStatus.CONFLICT)
                .body(apiResult);
    }


    /**
     * Company ni delete qiluvchi metod
     * @param id
     * @return ApiResult
     */


    @DeleteMapping("delete/{id}")
    public ResponseEntity<ApiResult> deleteCompany(@PathVariable Integer id) {
        ApiResult apiResult = companyService.deleteCompany(id);
        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.ACCEPTED : HttpStatus.CONFLICT)
                .body(apiResult);
    }
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }
}
