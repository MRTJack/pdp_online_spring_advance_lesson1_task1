//package uz.pdp.app_pdp_online_2_lesson1.task2.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//import uz.pdp.app_pdp_online_2_lesson1.task1.payload.ApiResult;
//import uz.pdp.app_pdp_online_2_lesson1.task2.dto.SubmissionDTO;
//import uz.pdp.app_pdp_online_2_lesson1.task2.dto.UserDTO;
//import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.Submission;
//import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.User;
//import uz.pdp.app_pdp_online_2_lesson1.task2.service.SubmissionService;
//import uz.pdp.app_pdp_online_2_lesson1.task2.service.UserService;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/api/users")
//public class UserController {
//    @Autowired
//    private UserService userService;
//    @Autowired
//    private SubmissionService submissionService;
//
//    /**
//     * Register qiluvchi controller
//     * @param userDTO
//     * @return ?
//     */
//    @PostMapping("/register")
//    public ResponseEntity<?> getRegister(@RequestBody UserDTO userDTO) {
//        ApiResult apiResult = userService.registerUser(userDTO);
//        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.CREATED : HttpStatus.CONFLICT)
//                .body(apiResult);
//    }
//
//    /**
//     * Login qilib kiruvchi controller
//     * @param userDTO
//     * @return ?
//     */
//    @PostMapping("/login")
//    public ResponseEntity<?> getLogin(@RequestBody UserDTO userDTO) {
//        ApiResult apiResult = userService.loginUser(userDTO);
//        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.ACCEPTED : HttpStatus.CONFLICT)
//                .body(apiResult);
//    }
//
//    /**
//     * Hozirgi user ni ohirgi bajargan sessiasi
//     * @param sessionId
//     * @return User
//     */
//    @GetMapping("/me")
//    public ResponseEntity<User> getCurrentUser(String sessionId) {
//        User currentUser = userService.getCurrentUser(sessionId);
//        return ResponseEntity.ok(currentUser);
//    }
//
//    /**
//     * Topshiriqni javobni yuborish uchun controller
//     * @param user_id
//     * @param submissionDTO
//     * @return ?
//     */
//    @PostMapping("/{user_id}/submissions")
//    public ResponseEntity<?> submitProblemSolution(@PathVariable Long user_id, @RequestBody SubmissionDTO submissionDTO) {
//        List<Submission> submissionByUserId = submissionService.getSubmissionByUserId(user_id);
//        return ResponseEntity.ok(submissionByUserId);
//    }
//}
