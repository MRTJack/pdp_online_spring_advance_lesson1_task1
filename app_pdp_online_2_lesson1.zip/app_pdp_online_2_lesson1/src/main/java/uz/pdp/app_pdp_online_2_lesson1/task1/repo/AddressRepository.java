package uz.pdp.app_pdp_online_2_lesson1.task1.repo;

import jakarta.validation.constraints.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Address;

import java.util.Optional;

public interface AddressRepository extends JpaRepository<Address, Integer> {
    boolean existsAddressByHomeNumber(@NotNull String phoneNumber);

    boolean existsAddressByHomeNumberAndIdNot(@NotNull String phoneNumber, Integer id);

}
