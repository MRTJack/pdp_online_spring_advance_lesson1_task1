package uz.pdp.app_pdp_online_2_lesson1.task1.dto;

public class ModelMapper {
}
