//package uz.pdp.app_pdp_online_2_lesson1.task2.serviceImpl;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import uz.pdp.app_pdp_online_2_lesson1.task1.payload.ApiResult;
//import uz.pdp.app_pdp_online_2_lesson1.task2.dto.UserDTO;
//import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.User;
//import uz.pdp.app_pdp_online_2_lesson1.task2.repo.UserRepository;
//import uz.pdp.app_pdp_online_2_lesson1.task2.service.UserService;
//
//import java.util.HashMap;
//import java.util.Map;
//
//@Service
//public class UserImpl implements UserService {
//    @Autowired
//    private UserRepository userRepository;
//    private final Map<String, User> loggedInUsers = new HashMap<>();
//
//    /**
//     * Registration metodi
//     *
//     * @param userDTO
//     * @return ApiResult
//     */
//    @Override
//    public ApiResult registerUser(UserDTO userDTO) {
//        try {
//            if (userRepository.existsByUsername(userDTO.getUsername())) {
//                return new ApiResult("Bunday ismli user mavjud", false);
//            }
//            User user = new User();
//            user.setUsername(userDTO.getUsername());
//            user.setPassword(userDTO.getPassword());
//            userRepository.save(user);
//            return new ApiResult("Yangi user yaratildi", true);
//        } catch (Exception e) {
//            return new ApiResult("Xatolik!!!", false);
//        }
//    }
//
//    /**
//     * Login metodi
//     *
//     * @param userDTO
//     * @return ApiResult
//     */
//    @Override
//    public ApiResult loginUser(UserDTO userDTO) {
//        try {
//            User user = userRepository.findByUsername(userDTO.getUsername());
//            if (user != null && user.getPassword().equals(userDTO.getPassword())) {
//                String sessionId = generateSessionId();
//                loggedInUsers.put(sessionId, user);
//                return new ApiResult("Muvaffaqiyatli kirdingiz", true);
//            } else {
//                return new ApiResult("Login yoki parol xato", false);
//            }
//        } catch (Exception e) {
//            return new ApiResult("Xatoli", false);
//        }
//    }
//
//    /**
//     * Noyob seans id yaratiladi
//     *
//     * @return String
//     */
//    private String generateSessionId() {
//        return "SESSION_" + System.currentTimeMillis();
//    }
//
//    /**
//     * Hozirgi login qilib kirilgan userni seansini kurish uchun yaratilgan metod
//     * @param sessionId
//     * @return User
//     */
//    @Override
//    public User getCurrentUser(String sessionId) {
//        return loggedInUsers.get(sessionId);
//    }
//}
