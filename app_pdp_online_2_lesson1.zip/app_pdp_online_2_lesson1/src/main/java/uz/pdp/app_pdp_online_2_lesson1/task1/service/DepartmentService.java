package uz.pdp.app_pdp_online_2_lesson1.task1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.pdp.app_pdp_online_2_lesson1.task1.dto.DepartmentDTO;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Department;
import uz.pdp.app_pdp_online_2_lesson1.task1.payload.ApiResult;
import uz.pdp.app_pdp_online_2_lesson1.task1.repo.CompanyRepository;
import uz.pdp.app_pdp_online_2_lesson1.task1.repo.DepartmentRepository;

import java.util.List;
import java.util.Optional;

@Service
public class DepartmentService {
    final
    DepartmentRepository departmentRepository;
    final
    CompanyRepository companyRepository;

    public DepartmentService(CompanyRepository companyRepository, DepartmentRepository departmentRepository) {
        this.companyRepository = companyRepository;
        this.departmentRepository = departmentRepository;
    }

    public List<Department> getAllDepartment() {
        return departmentRepository.findAll();
    }

    public Department getDepartmentById(Long id) {
        Optional<Department> byId = departmentRepository.findById(id);
        return byId.orElse(null);
    }

    public ApiResult addDepartment(DepartmentDTO departmentDTO) {
        Long companyId = departmentDTO.getCompanyId();

        if (companyId == null) {
            return new ApiResult("Kompaniya identifikatori noto‘g‘ri", false);
        }

        return companyRepository.findById(companyId)
                .map(company -> {
                    Department newDepartment = new Department();
                    newDepartment.setName(departmentDTO.getName());
                    newDepartment.setCompany(company);
                    departmentRepository.save(newDepartment);
                    return new ApiResult("Department muvaffaqiyatli qo'shildi", true);
                })
                .orElse(new ApiResult("Kompaniya topilmadi", false));
    }

    public ApiResult editDepartment(DepartmentDTO departmentDTO, Integer id) {
        String newDepartmentName = departmentDTO.getName();

        if (departmentRepository.existsDepartmentByCompany_DirectorNameAndIdNot(newDepartmentName, id)) {
            return new ApiResult("Bunday nomli department mavjud", false);
        }

        return departmentRepository.findById(id.longValue())
                .map(department -> updateDepartmentFromDTO(department, newDepartmentName))
                .map(departmentRepository::save)
                .map(savedDepartment -> new ApiResult("Department tahririlandi", true))
                .orElse(new ApiResult("Bunday department mavjud emas", false));
    }

    private Department updateDepartmentFromDTO(Department department, String newDepartmentName) {
        department.setName(newDepartmentName);
        return department;
    }

    public ApiResult deleteDepartment(Long id) {
        try {
            departmentRepository.deleteById(id);
            return new ApiResult("Departmnet uchirildi", true);
        } catch (Exception e) {
            return new ApiResult("Xatolik!!!", false);
        }
    }

}

