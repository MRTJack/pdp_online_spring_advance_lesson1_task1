package uz.pdp.app_pdp_online_2_lesson1.task1.service;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.pdp.app_pdp_online_2_lesson1.task1.dto.AddressDTO;
import uz.pdp.app_pdp_online_2_lesson1.task1.dto.WorkerDTO;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Address;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Department;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Worker;
import uz.pdp.app_pdp_online_2_lesson1.task1.payload.ApiResult;
import uz.pdp.app_pdp_online_2_lesson1.task1.repo.WorkerRepository;

import java.util.List;

@Service
public class WorkerService {
    @Autowired
    private WorkerRepository workerRepository;

    @Autowired
    private AddressService addressService;  // Assuming you have an AddressService

    @Autowired
    private DepartmentService departmentService;  // Assuming you have a DepartmentService

    public List<Worker> getAllWorkers() {
        return workerRepository.findAll();
    }

    public Worker getWorkerById(Integer id) {
        return workerRepository.findById(id).orElse(null);
    }

    public ApiResult addWorker(WorkerDTO workerDTO) {
        if (workerRepository.existsWorkerByPhoneNumber(workerDTO.getPhoneNumber())) {
            return new ApiResult("Bu telefon raqamiga ega ishchi allaqachon mavjud", false);
        }

        Worker worker = new Worker();
        worker.setFull_name(workerDTO.getName());
        worker.setPhoneNumber(workerDTO.getPhoneNumber());

        AddressDTO addressDTO = workerDTO.getAddress();
        Address address = new Address();
        address.setStreet(addressDTO.getStreet());
        address.setHomeNumber(addressDTO.getHomeNumber());
        addressService.addAddress(address);

        worker.setAddress(address);

        Department department = departmentService.getDepartmentById(workerDTO.getDepartmentId());
        if (department == null) {
            return new ApiResult("Bunday department mavjud emas", false);
        }

        worker.setDepartment(department);

        workerRepository.save(worker);
        return new ApiResult("Worker muvaffaqiyatli qushildi", true);
    }

    public ApiResult editWorker(@Valid Integer id, WorkerDTO workerDTO) {
        Worker existingWorker = workerRepository.findById(id).orElse(null);
        if (existingWorker == null) {
            return new ApiResult("Worker not found", false);
        }

        existingWorker.setFull_name(workerDTO.getName());
        existingWorker.setPhoneNumber(workerDTO.getPhoneNumber());

        AddressDTO updatedAddressDTO = workerDTO.getAddress();
        Address existingAddress = existingWorker.getAddress();
        existingAddress.setStreet(updatedAddressDTO.getStreet());
        existingAddress.setHomeNumber(updatedAddressDTO.getHomeNumber());

        Department existingDepartment = existingWorker.getDepartment();
        Department updatedDepartment = departmentService.getDepartmentById(workerDTO.getDepartmentId());
        if (updatedDepartment == null) {
            return new ApiResult("Department mavjud emas", false);
        }

        existingWorker.setDepartment(updatedDepartment);

        workerRepository.save(existingWorker);
        return new ApiResult("Worker muvaffaqiyatli yangilandi", true);
    }

    public ApiResult deleteWorker(Long id) {
        Worker worker = workerRepository.findById(id).orElse(null);
        if (worker == null) {
            return new ApiResult("Worker mavjud emas", false);
        }

        workerRepository.delete(worker);
        return new ApiResult("Worker muvvafaqiyatli uchirildi", true);
    }
}
