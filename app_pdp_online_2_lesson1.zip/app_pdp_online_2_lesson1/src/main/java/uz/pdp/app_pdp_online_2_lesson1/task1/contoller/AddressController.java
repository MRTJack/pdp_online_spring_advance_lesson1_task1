package uz.pdp.app_pdp_online_2_lesson1.task1.contoller;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import uz.pdp.app_pdp_online_2_lesson1.task1.dto.AddressDTO;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Address;
import uz.pdp.app_pdp_online_2_lesson1.task1.payload.ApiResult;
import uz.pdp.app_pdp_online_2_lesson1.task1.service.AddressService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/address")
public class AddressController {
    @Autowired
    AddressService addressService;

    /**
     * Addresslar ruyhatini qaytaradi
     *
     * @return Address
     */
    @GetMapping("")
    public ResponseEntity<List<Address>> getAddresses() {
        List<Address> addressList = addressService.getAllAddresses();
        return ResponseEntity.ok(addressList);
    }


    /**
     * Address ni id orqali qaytaradi
     *
     * @param id
     * @return Address
     */
    @GetMapping("/{id}")
    public HttpEntity<Address> getAddress(@PathVariable Integer id) {
        Address addressById = addressService.getAddressById(id);
        return ResponseEntity.ok(addressById);
    }

    /**
     * Address qushadigan metod
     *
     * @param addressDTO
     * @return ApiResult
     */
    @PostMapping("/add")
    public HttpEntity<ApiResult> addAddress(@Valid @RequestBody AddressDTO addressDTO) {
        ApiResult apiResult = addressService.addAddress(addressDTO);
        return ResponseEntity.status(apiResult.isSuccess()
                ? HttpStatus.CREATED : HttpStatus.CONFLICT).body(apiResult);
    }

    /**
     * Address ni edit qiladigan metod
     *
     * @param id
     * @param addressDTO
     * @return ApiResult
     */

    @PutMapping("/edit/{id}")
    public HttpEntity<ApiResult> editAddress(@Valid @PathVariable Integer id, @RequestBody AddressDTO addressDTO) {
        ApiResult apiResult = addressService.editAddress(id, addressDTO);
        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.ACCEPTED
                : HttpStatus.CONFLICT).body(apiResult);
    }


    /**
     * Address ni uchiradigan metod
     *
     * @param id
     * @return ApiResult
     */

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<ApiResult> deleteAddress(@PathVariable Integer id) {
        ApiResult apiResult = addressService.deleteAddress(id);
        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.ACCEPTED : HttpStatus.CONFLICT)
                .body(apiResult);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }
}
