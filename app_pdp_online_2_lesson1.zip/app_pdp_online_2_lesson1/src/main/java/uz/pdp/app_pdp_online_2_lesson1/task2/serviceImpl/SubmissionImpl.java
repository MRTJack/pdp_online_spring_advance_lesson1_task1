//package uz.pdp.app_pdp_online_2_lesson1.task2.serviceImpl;
//
//import jakarta.persistence.EntityNotFoundException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import uz.pdp.app_pdp_online_2_lesson1.task1.payload.ApiResult;
//import uz.pdp.app_pdp_online_2_lesson1.task2.dto.SubmissionDTO;
//import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.Submission;
//import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.User;
//import uz.pdp.app_pdp_online_2_lesson1.task2.repo.SubmissionRepository;
//import uz.pdp.app_pdp_online_2_lesson1.task2.repo.UserRepository;
//import uz.pdp.app_pdp_online_2_lesson1.task2.service.SubmissionService;
//
//import java.util.List;
//
//@Service
//public class SubmissionImpl implements SubmissionService {
//    @Autowired
//    SubmissionRepository submissionRepository;
//    @Autowired
//    private UserRepository userRepository;
//
//    /**
//     * Hamma submissionlar ruyhatini qaytaradi
//     *
//     * @return Submission
//     */
//    @Override
//    public List<Submission> getAllSubmissionForUser() {
//        return submissionRepository.findAll();
//    }
//
//    /**
//     * Userni id siga qarab submissionni chiqarib beradi
//     * @param user
//     * @return
//     */
//    @Override
//    public List<Submission> getSubmissionByUserId(Long user) {
//        return submissionRepository.findByUserId(user);
//    }
//
//    /**
//     * User topshiriqga javob topadi, agar bulmasa uzi yaratadi
//     * @param submissionDTO
//     * @param userId
//     * @return ApiResult
//     */
//    @Override
//    public ApiResult submitSolution(SubmissionDTO submissionDTO, Long userId) {
//        // Shunaqa id li user mavjud ligini tekshirib kuramiz
//        User user = userRepository.findById(userId)
//                .orElseThrow(() -> new EntityNotFoundException(userId + " shunaqa id li foydalanuvchi mavjud emas"));
//
//        // Shunaqa id li solution shu user id siga tegishlimi yoki yuq tekshirib kuramiz
//        Submission existingSubmission = submissionRepository.findByIdAndUserId(submissionDTO.getId(), userId);
//
//        if (existingSubmission != null) {
//            // Agar yechim bor bulsa uni tahrirlaymiz
//            updateExistingSubmission(existingSubmission, submissionDTO);
//            return new ApiResult("Solution tahrirlandi", true);
//        }
//        return new ApiResult("Uzur suraymiz dasturchi hali bilmagan narsalari" +
//                " bor shu sababli yangi solution yaratish logikasini " +
//                "yarata olmadi", false);
//    }
//
//    private void updateExistingSubmission(Submission existingSubmission, SubmissionDTO submissionDTO) {
//        existingSubmission.setSolution(submissionDTO.getSolution());
//        submissionRepository.save(existingSubmission);
//    }
//
//    /**
//     * submission haqida
//     * @param submissionId
//     * @return submission
//     */
//    @Override
//    public Submission getSubmissionDetails(Long submissionId) {
//        return submissionRepository.findById(submissionId)
//                .orElseThrow(() -> new EntityNotFoundException(("Submission topilmadi")));
//    }
//}
