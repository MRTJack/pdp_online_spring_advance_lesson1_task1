package uz.pdp.app_pdp_online_2_lesson1.videoDars.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.pdp.app_pdp_online_2_lesson1.videoDars.dto.CustomerDTO;
import uz.pdp.app_pdp_online_2_lesson1.videoDars.entity.Customer;
import uz.pdp.app_pdp_online_2_lesson1.videoDars.payload.ApiResult;
import uz.pdp.app_pdp_online_2_lesson1.videoDars.repo.CustomerRepository;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {
    @Autowired
    CustomerRepository customerRepository;

    /**
     * Bu yerda mijozlar ruyxatini qaytaramiz
     *
     * @return CUSTOMERS
     */
    public List<Customer> getCustomers() {
        return customerRepository.findAll();
    }

    /**
     * ID orqali bitta mijozni qaytaramiz
     *
     * @param id INTEGER
     * @return CUSTOMER
     */
    public Customer getCustomerById(Integer id) {
        Optional<Customer> optionalCustomer = customerRepository.findById(id);
        return optionalCustomer.orElse(null);
    }

    /**
     * Mijoz qushadigan metod
     *
     * @return ApiResult
     * Bizga CustomerDTO tipida JSON object keladi
     * Validatsiya quydik
     */
    public ApiResult addCustomer(CustomerDTO customerDTO) {
        boolean existsByPhoneNumber = customerRepository.existsByPhoneNumber(customerDTO.getPhoneNumber());
        if (existsByPhoneNumber) {
            return new ApiResult("Bunday mijoz mavjud", false);
        }
        Customer customer = new Customer();
        customer.setPhoneNumber(customerDTO.getPhoneNumber());
        customer.setFull_name(customerDTO.getFull_name());
        customer.setAddress(customerDTO.getAddress());

        customerRepository.save(customer);
        return new ApiResult("Mijoz saqlandi", true);
    }

    /**
     * Mijozni tahrirlash
     *
     * @return ApiResult
     * Bizga yulda Id va RequestBodysida CustomerDTO tipida JSON object beradi
     **/
    public ApiResult editCustomer(Integer id, CustomerDTO customerDTO) {
        return customerRepository.existsByPhoneNumberAndIdNot(customerDTO.getPhoneNumber(), id)
                ? new ApiResult("Bunday telefon raqamli mijos mavjud", false)
                : customerRepository.findById(id)
                .map(customer -> updateCustomerFromDTO(customer, customerDTO))
                .map(customerRepository::save)
                .map(savedCustomer -> new ApiResult("Mijoz tahrirlandi", true))
                .orElse(new ApiResult("Bunday mijoz mavjud emas", false));
    }

    private Customer updateCustomerFromDTO(Customer customer, CustomerDTO customerDTO) {
        customer.setAddress(customerDTO.getAddress());
        customer.setPhoneNumber(customerDTO.getPhoneNumber());
        customer.setFull_name(customerDTO.getFull_name());
        return customer;
    }


    /**
     * Mijozni uchirish id orqali yulda id ni beradi
     *
     * @return ApiResult
     */
    public ApiResult deleteCustomer(Integer id) {
        try {
            customerRepository.deleteById(id);
            return new ApiResult("Mijoz uchirildi", true);
        }catch (Exception e ){
            return new ApiResult("Xatolik!!!", false);
        }
    }
}