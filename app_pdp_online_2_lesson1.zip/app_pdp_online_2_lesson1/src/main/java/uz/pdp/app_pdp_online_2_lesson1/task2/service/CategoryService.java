package uz.pdp.app_pdp_online_2_lesson1.task2.service;

import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.Category;
import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.Problem;
import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.Subcategory;

import java.util.List;

public interface CategoryService {
    List<Category> getAllCategories();

    List<Subcategory> getSubcategoriesByCategoryId(Long categoryId);

    List<Problem> getProblemsBySubcategoryId(Long subcategoryId);
}

