package uz.pdp.app_pdp_online_2_lesson1.task1.eninty;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import uz.pdp.app_pdp_online_2_lesson1.task1.dto.AddressDTO;

import java.util.List;

// Address
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Address {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String street;

    @Column(unique = true, nullable = false)
    private String homeNumber;

    @OneToMany(mappedBy = "address")
    private List<Worker> workers;

}

