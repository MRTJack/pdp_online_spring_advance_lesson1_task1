package uz.pdp.app_pdp_online_2_lesson1.task1.contoller;

import jakarta.validation.Valid;
import org.hibernate.id.IntegralDataTypeHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import uz.pdp.app_pdp_online_2_lesson1.task1.dto.WorkerDTO;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Worker;
import uz.pdp.app_pdp_online_2_lesson1.task1.payload.ApiResult;
import uz.pdp.app_pdp_online_2_lesson1.task1.service.WorkerService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/worker")
public class WorkerController {
    @Autowired
    WorkerService workerService;

    @GetMapping("")
    public ResponseEntity<List<Worker>> getWorker() {
        List<Worker> worker = workerService.getAllWorkers();
        return ResponseEntity.ok(worker);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Worker> getWorkerById(@PathVariable Integer id) {
        Worker workerById = workerService.getWorkerById(id);
        return ResponseEntity.ok(workerById);
    }

    @PostMapping("/add")
    public ResponseEntity<ApiResult> addWorker(@Valid @RequestBody WorkerDTO workerDTO) {
        ApiResult apiResult = workerService.addWorker(workerDTO);
        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.CREATED : HttpStatus.CONFLICT)
                .body(apiResult);
    }

    @PutMapping("/edit/{id}")
    public ResponseEntity<ApiResult> editWorker(@Valid @PathVariable Integer id, @RequestBody WorkerDTO workerDTO) {
        ApiResult apiResult = workerService.editWorker(id, workerDTO);
        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.ACCEPTED : HttpStatus.CONFLICT)
                .body(apiResult);
    }

    @DeleteMapping("/delete/{id}")
    public ApiResult deleteWorker(@PathVariable Long id) {
        ApiResult apiResult = workerService.deleteWorker(id);
        return ResponseEntity.status(apiResult.isSuccess() ? HttpStatus.ACCEPTED : HttpStatus.CONFLICT)
                .body(apiResult).getBody();
    }
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }
}
