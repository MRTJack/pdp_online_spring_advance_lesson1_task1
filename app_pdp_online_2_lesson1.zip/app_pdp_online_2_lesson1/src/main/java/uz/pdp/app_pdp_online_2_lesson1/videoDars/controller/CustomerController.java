package uz.pdp.app_pdp_online_2_lesson1.videoDars.controller;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import uz.pdp.app_pdp_online_2_lesson1.videoDars.dto.CustomerDTO;
import uz.pdp.app_pdp_online_2_lesson1.videoDars.entity.Customer;
import uz.pdp.app_pdp_online_2_lesson1.videoDars.payload.ApiResult;
import uz.pdp.app_pdp_online_2_lesson1.videoDars.service.CustomerService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
//@RequestMapping("/api/customers")
public class CustomerController {
    @Autowired
    CustomerService customerService;


    /**
     * Bu yerda barcha mijozlar ruyxatini qaytaramiz
     *
     * @return CUSTOMERS
     */
    @GetMapping("/api/customers")
    public List<Customer> getCustomers() {
        return customerService.getCustomers();
    }

    /**
     * ID orqali bitta mijozni qaytaramiz
     *
     * @param id INTEGER
     * @return CUSTOMER
     * Agar ID orqali mijoz topilmasa null qiymat qaytsin
     */
    @GetMapping("/api/customers/{id}")
    public Customer getCustomer(@PathVariable Integer id) {
        return customerService.getCustomerById(id);
    }


    /**
     * Mijoz qushadigan metod
     *
     * @return ApiResult
     * Bizga CustomerDTO tipida JSON object keladi
     * Validatsiya quydik
     */
    @PostMapping("/api/customers/add")
    public ApiResult addCustomer(@Valid @RequestBody CustomerDTO customerDTO) {
        return customerService.addCustomer(customerDTO);
    }


    /**
     * Mijozni tahrirlash
     *
     * @param id
     * @param customerDTO
     * @return ApiResult
     * Bizga yulda Id va RequestBodysida CustomerDTO tipida JSON object beradi
     */

    @PutMapping("/api/customers/edit/{id}")
    public ApiResult editCustomer(@Valid @PathVariable Integer id, @RequestBody CustomerDTO customerDTO) {
        return customerService.editCustomer(id, customerDTO);
    }

    /**
     * Mijozni uchirish id orqali yulda id ni beradi
     *
     * @param id
     * @return ApiResult
     */
    @DeleteMapping("/api/customers/delete/{id}")
    public ApiResult deleteCustomer(@PathVariable Integer id) {
        return customerService.deleteCustomer(id);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(
            MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }

}
