package uz.pdp.app_pdp_online_2_lesson1.task1.repo;

import jakarta.validation.constraints.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Company;

import java.util.Optional;

public interface CompanyRepository extends JpaRepository<Company, Long> {
    boolean existsCompaniesByCorpName(@NotNull String corpName);

    boolean existsCompaniesByCorpNameAndIdNot(String corpName, Integer id);

    Optional<Company> findById(Integer id);

    void deleteById(Integer id);
}

