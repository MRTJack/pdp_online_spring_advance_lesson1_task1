package uz.pdp.app_pdp_online_2_lesson1.task1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.pdp.app_pdp_online_2_lesson1.task1.dto.AddressDTO;
import uz.pdp.app_pdp_online_2_lesson1.task1.eninty.Address;
import uz.pdp.app_pdp_online_2_lesson1.task1.payload.ApiResult;
import uz.pdp.app_pdp_online_2_lesson1.task1.repo.AddressRepository;

import java.util.List;

@Service
public class AddressService {
    @Autowired
    private AddressRepository addressRepository;

    public List<Address> getAllAddresses() {
        return addressRepository.findAll();
    }

    public Address getAddressById(Integer id) {
        return addressRepository.findById(id).orElse(null);
    }

    public ApiResult addAddress(Address addressDTO) {
        boolean existsAddressByHomeNumber = addressRepository.existsAddressByHomeNumber(addressDTO.getHomeNumber());
        if (existsAddressByHomeNumber) {
            return new ApiResult("Bunday address mavjud", false);
        }
        Address address = new Address();
        address.setStreet(addressDTO.getStreet());
        address.setHomeNumber(addressDTO.getHomeNumber());
        addressRepository.save(address);
        return new ApiResult("Address saqlandi", true);
    }
    public ApiResult editAddress(Integer id, AddressDTO addressDTO) {
        return addressRepository.existsAddressByHomeNumberAndIdNot(addressDTO.getHomeNumber(),id)
                ? new ApiResult("Bunday raqamli address  mavjud", false)
                : addressRepository.findById(id)
                .map(address -> updateAddressFromDTO(address, addressDTO))
                .map(addressRepository::save)
                .map(savedAddress -> new ApiResult("Address tahrirlandi", true))
                .orElse(new ApiResult("Bunday address mavjud emas", false));
    }

    private Address updateAddressFromDTO(Address address, AddressDTO addressDTO) {
        address.setStreet(addressDTO.getStreet());
        address.setHomeNumber(addressDTO.getHomeNumber());
        return address;
    }

    public ApiResult deleteAddress(Integer id) {
        try {
            addressRepository.deleteById(id);
            return new ApiResult("Address uchirildi", true);
        } catch (Exception e) {
            return new ApiResult("Xatolik!!!", false);
        }
    }
}

