//package uz.pdp.app_pdp_online_2_lesson1.task2.repo;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.Submission;
//
//import java.util.List;
//
//public interface SubmissionRepository extends JpaRepository<Submission, Long> {
//    List<Submission> findByUserId(Long userId);
//
//    Submission findByIdAndUserId(Long id, Long userId);
//}
