package uz.pdp.app_pdp_online_2_lesson1.task2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.Category;
import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.Problem;
import uz.pdp.app_pdp_online_2_lesson1.task2.eninty.Subcategory;
import uz.pdp.app_pdp_online_2_lesson1.task2.service.CategoryService;

import java.util.List;

@RestController
@RequestMapping("/api/categories ")
public class CategoryController {
    @Autowired
    private CategoryService categoryService;
    /**
     * Category lar ruyhatini qaytaradi
     *
     * @return
     */
    @GetMapping()
    public ResponseEntity<List<Category>> getCategories() {
        List<Category> allCategories = categoryService.getAllCategories();
        return ResponseEntity.ok(allCategories);
    }

    /**
     * Category uchun subcategory olish controller
     * @param categoryId
     * @return Subcategory
     */
    @GetMapping("/{category_id}/subcategories")
    public ResponseEntity<List<Subcategory>> categoriesIdBySubcategory(@PathVariable Long categoryId) {
        List<Subcategory> subcategoriesByCategoryId = categoryService.getSubcategoriesByCategoryId(categoryId);
        return ResponseEntity.ok(subcategoriesByCategoryId);
    }


    /**
     * Subcategory uchun topshiriq olish controlleri
     * @param subcategory_id
     * @return
     */
    @GetMapping("/subcategories/{subcategory_id}/problems")
    public ResponseEntity<List<Problem>> getProblemsForSubcategory(@PathVariable Long subcategory_id) {
        List<Problem> problemsBySubcategoryId = categoryService.getProblemsBySubcategoryId(subcategory_id);
        return ResponseEntity.ok(problemsBySubcategoryId);
    }

}
